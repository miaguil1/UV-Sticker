README
~~~~~~
1. cy8c4xx7xxx-bl4x3.ibs : IBIS file for PSoC 4 BLE family products
2. cybl10xxx-xxxxx.ibs : IBIS file for PRoC BLE family products

Both these files are exact copies of each other EXCEPT for the part numbers section.
Both are compliant to IBIS 4.0 version and have been checked with HyperLynx 4.1 (Built 169) visual IBIS editor.