/*******************************************************************************
* File Name: main.c
*
* 
*
* Description:
*  This project demonstrates the low power implementation in
*  advertising state of BLE
*
* Note:
* 
* Hardware Dependency:
*  CY8CKIT-042 BLE
*
********************************************************************************
* Copyright 2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "project.h"

#define CAPACITOR_TRIM_VALUE       0x00004355

#define ManageBlePower()            CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP)

/* Comment the below line if no data is to be sent */
#define ENABLE_NOTIFICATION        1

#define NOTIFICATION_OFFSET        2
#define CONNECTION_UPDATE          1
             


/******************************************************************************
Global variables declaration
*******************************************************************************/
CYBLE_API_RESULT_T apiResult;
typedef enum PowerMode_t {
    WAKEUP_SLEEP,
    WAKEUP_DEEPSLEEP,
    ACTIVE,
    SLEEP,
    DEEPSLEEP
} PowerMode_t;

PowerMode_t applicationPower;
CYBLE_API_RESULT_T apiResult;
uint8 connected, notificationState, initCount, connUpdate;
#if ENABLE_NOTIFICATION
/* This array contains the values to be sent when notifications is enabled  *
 * Change the array size (minimum 1; maximum 20) and elements as needed     */
uint8 heartRatePacket[2] = {0x01,0x02};
#endif

/*******************************************************************************
* Function Name: AppCallBack()
********************************************************************************
*
* Summary:
*   This is an event callback function to receive events from the BLE Component.
*
* Parameters:
*  event - the event code
*  *eventParam - the event parameters
*
*******************************************************************************/
void AppCallBack(uint32 event, void* eventParam)
{
    CYBLE_BLESS_CLK_CFG_PARAMS_T clockConfig;
    
    (void)eventParam;
    
    switch(event)
    {
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            /* Update connection and notification state variable status */
            connected = 0;
            notificationState = 0;
            #if ENABLE_NOTIFICATION
            initCount = 0;
            #endif    
		
        case CYBLE_EVT_STACK_ON:

            /* load capacitors on the ECO should be tuned and the tuned value
            ** must be set in the CY_SYS_XTAL_BLERD_BB_XO_CAPTRIM_REG  */
            CY_SYS_XTAL_BLERD_BB_XO_CAPTRIM_REG = CAPACITOR_TRIM_VALUE;    
        
            /* Get the configured clock parameters for BLE sub-system */
            CyBle_GetBleClockCfgParam(&clockConfig);    
            
            /* Update the sleep clock inaccuracy PPM based on WCO crystal used */
            /* If you see frequent link disconnection, tune your WCO or update the sleep clock accuracy here */
            clockConfig.bleLlSca =   CYBLE_LL_SCA_000_TO_020_PPM;
            
            /* set the clock configuration parameter of BLE sub-system with updated values*/
            CyBle_SetBleClockCfgParam(&clockConfig);
 
            
            /* Put the device into discoverable mode so that a central device can connect to it */
            apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            break;
			
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            /* Update connection state variable status */            
            connected = 1;
            break;
            
        default:
            break;
    }
}

/*******************************************************************************
* Function Name: ManageSystemPower()
********************************************************************************
*
* Summary:
*   This function puts the system in appropriate low power modes based on the 
*   state of BLESS and application power state.
*
* Parameters:
*  none
*
********************************************************************************/
__inline void ManageSystemPower()
{
    /* Variable declarations */
    CYBLE_BLESS_STATE_T blePower;
    uint8 interruptStatus ;
    
   /* Disable global interrupts to avoid any other tasks from interrupting this section of code*/
    interruptStatus  = CyEnterCriticalSection();
    
    /* Get current state of BLE sub system to check if it has successfully entered deep sleep mode */
    blePower = CyBle_GetBleSsState();
    
    /* System can enter DeepSleep only when BLESS and rest of the application are in DeepSleep 
     * power modes */
    if((blePower == CYBLE_BLESS_STATE_DEEPSLEEP || blePower == CYBLE_BLESS_STATE_ECO_ON) && 
        applicationPower == DEEPSLEEP)
    {
        applicationPower = WAKEUP_DEEPSLEEP;   
        CySysPmDeepSleep(); 
    }
    else if((blePower != CYBLE_BLESS_STATE_EVENT_CLOSE))
    {
        if(applicationPower == DEEPSLEEP)
        {
            applicationPower = WAKEUP_DEEPSLEEP;
            
            /* change HF clock source from IMO to ECO, as IMO is not required and can be stopped to save power */
            CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_ECO); 
            /* stop IMO for reducing power consumption */
            CySysClkImoStop();              
            /* put the CPU to sleep */
            CySysPmSleep();            
            /* starts execution after waking up, start IMO */
            CySysClkImoStart();
            /* change HF clock source back to IMO */
            CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_IMO);
			
        }
        else if(applicationPower == SLEEP )
        {
            /* If the application requires IMO for its operation, we should not switch the HFCLK source */
            applicationPower = WAKEUP_SLEEP;        
            CySysPmSleep();            
            
        }
    }
    
    /* Enable interrupts */
    CyExitCriticalSection(interruptStatus );

}

/*******************************************************************************
* Function Name: ManageApplicationPower()
********************************************************************************
*
* Summary:
*   This function puts the application componnents in appropriate low power modes 
*   based on the state of the components.
*
* Parameters:
*  none
*
********************************************************************************/
__inline void ManageApplicationPower()
{
    switch(applicationPower)
    {
        case ACTIVE: // dont need to do anything
        break;
        
        case WAKEUP_SLEEP: // do whatever wakeup needs to be done - probably never do anything
        
            applicationPower = ACTIVE;
        break;
        
        case WAKEUP_DEEPSLEEP: // do whatever wakeup needs to be done.
        
            applicationPower = ACTIVE;
        break;
        
        case SLEEP: 
        /** Add code to place the application components to sleep here  */
        break;
        
        case DEEPSLEEP:
        /** Add code to place the application components to deep sleep here  */
        
        break;
    }
}

/*******************************************************************************
* Function Name: RunApplication()
********************************************************************************
*
* Summary:
*   This function runs application specific code. this is a template. This function
*   may be replaced by customer specific functions. 
*
* Parameters:
*  none
*
********************************************************************************/
__inline void RunApplication()
{
    /** Place your application code here **/
    
    /* Once application is done with all processing, enter low-power mode */
    if(0) /* if you are ready to sleep then set it up to go to sleep */
    {
        applicationPower = SLEEP;
    }
    
    if(1) /* if you are done with everything, then deepsleep */
    {
        applicationPower = DEEPSLEEP;
    }
}

#if ENABLE_NOTIFICATION
    

/*******************************************************************************
* Function Name: HeartRateCallBack()
********************************************************************************
* Call back function for the Heart Rate Service
*
* Parameters:
*  event       - the event code
*  eventParam - the event parameters
*******************************************************************************/
void HeartRateCallBack(uint32 event, void* eventParam)
{

    switch(event)
    {

        case CYBLE_EVT_HRSS_NOTIFICATION_ENABLED:
            connUpdate = 1;
            notificationState = 1;
        break;
        
        case CYBLE_EVT_HRSS_NOTIFICATION_DISABLED:
            notificationState = 0;
            connUpdate = 0;
        break;
    }

    if(0u != eventParam)
    {

        /* This dummy operation is to avoid warning about unused eventParam */
    } 
}

/*******************************************************************************
* Function Name: RunBle()
********************************************************************************
*  Run BLE specific tasks
*
* Parameters: 
* None
*******************************************************************************/

void RunBle()
{ 
    CyBle_ProcessEvents(); 
    /* Below code section enables updating connection interval from peripheral side. 
     * This is useful when you are testing with a smartphone that sets a connection
     * interval that is different from desired interval for measurement */
    #if CONNECTION_UPDATE
    if(connected && connUpdate)
    {
        CYBLE_API_RESULT_T conResult;
        static CYBLE_GAP_CONN_UPDATE_PARAM_T hrmConnectionParam =
        {
            800,        /* Minimum connection interval of 1000 ms */
            800,        /* Maximum connection interval of 1000 ms */
            0,          /* Slave latency */
            500        /* Supervision timeout of 5 seconds */
        };

        conResult = CyBle_L2capLeConnectionParamUpdateRequest(cyBle_connHandle.bdHandle, &hrmConnectionParam);
            
        if(conResult != CYBLE_ERROR_OK)
        {
           connUpdate = 0;
        }
        }
   #endif
         
   #if ENABLE_NOTIFICATION
   /* Wait until BLESS is in ECO_STABLE state to push the notification data to the BLESS */
   if(CyBle_GetBleSsState() == CYBLE_BLESS_STATE_ECO_STABLE && notificationState)
   {
       /* Wait for 'NOTIFICATION_OFFSET' connection intervals before starting notifications */
       if(initCount < NOTIFICATION_OFFSET) 
       {
           initCount++;
       }
       else
       {   
           /* Dummy incementing the notification data to simulate changing data */
           ++(heartRatePacket[1]); 
           /* Send notification to the client device */
           CyBle_HrssSendNotification(cyBle_connHandle, CYBLE_HRS_HRM, sizeof(heartRatePacket), heartRatePacket);
       }
   }
   #endif			

}

#endif
/*******************************************************************************
* Function Name: main()
********************************************************************************
*
* Summary:
*   This is the main function.
*
* Parameters:
* none
*
*******************************************************************************/
int main()
{

    /* Enable global interrupts */
    CyGlobalIntEnable;
       
    /* Internal low power oscillator is stopped as it is not used in this project */
    CySysClkIloStop();
    
    /* Set the divider for ECO, ECO will be used as source when IMO is switched off to save power */
    CySysClkWriteEcoDiv(CY_SYS_CLK_ECO_DIV8);

    /* Start CYBLE component and register the generic event handler */
    apiResult = CyBle_Start(AppCallBack);
       
    /* Initialize BLE HRS service */
    CyBle_HrsRegisterAttrCallback(HeartRateCallBack);
    
    /* Wait for BLE Component to complete Initialization */
    while (CyBle_GetState() == CYBLE_STATE_INITIALIZING)
    {
        CyBle_ProcessEvents(); 
    }
   
    applicationPower = ACTIVE;
    
    /*If DEEPSLEEP_ONLY is enabled, then the device stays in deep sleep all the time  
    * This is a good way to check if there are any leakage currents in the device. */
    #if DEEPSLEEP_ONLY
    CySysClkEcoStop();    
    CySysPmDeepSleep();
    while(1);
    #endif    

    /***************************************************************************
    * Main polling loop
    ***************************************************************************/
    while(1)
    {
        /***********************************************************************
        *  Process all BLE events from the BLE component
        ***********************************************************************/
	RunBle();

        /***********************************************************************
        *  Put BLE sub system in DeepSleep mode when it is idle
        ***********************************************************************/ 
        ManageBlePower();
    
        /***********************************************************************
        *  Run your application specific code here
        ***********************************************************************/  
        if(applicationPower == ACTIVE)
        {
            RunApplication();
        }
        
        /***********************************************************************
        *  Process application power modes
        ***********************************************************************/
        ManageApplicationPower();   
        
        /***********************************************************************
        *  Manage system power mode based on application and BLE power modes
        ***********************************************************************/
        ManageSystemPower();
    }
}
/* [] END OF FILE */
