/*******************************************************************************
* File Name: h2.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_h2_ALIASES_H) /* Pins h2_ALIASES_H */
#define CY_PINS_h2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define h2_0			(h2__0__PC)
#define h2_0_PS		(h2__0__PS)
#define h2_0_PC		(h2__0__PC)
#define h2_0_DR		(h2__0__DR)
#define h2_0_SHIFT	(h2__0__SHIFT)
#define h2_0_INTR	((uint16)((uint16)0x0003u << (h2__0__SHIFT*2u)))

#define h2_INTR_ALL	 ((uint16)(h2_0_INTR))


#endif /* End Pins h2_ALIASES_H */


/* [] END OF FILE */
