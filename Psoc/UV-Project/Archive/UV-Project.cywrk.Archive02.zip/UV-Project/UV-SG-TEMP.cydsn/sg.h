#ifndef __SG_H
#define __SG_H
#include "system.h"
    
float sg_measure(void);
float sg_get_strain(void);
void uv_get_pd_string(char*);
void sg_uart();

#endif // __SG_H
