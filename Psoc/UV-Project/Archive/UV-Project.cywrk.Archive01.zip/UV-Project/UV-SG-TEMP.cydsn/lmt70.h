#ifndef __LMT70_H
#define __LMT70_H
#include "system.h"
    
float lmt70_get_celsius(void);
void lmt70_string_celsius(char*);
void lmt70_uart(void);

#endif // __LMT70_H
