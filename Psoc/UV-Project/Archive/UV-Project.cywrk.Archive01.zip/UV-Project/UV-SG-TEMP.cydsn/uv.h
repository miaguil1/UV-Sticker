#ifndef __UV_H
#define __UV_H
#include "system.h"
    
float uv_measure(unsigned int);
float uv_get_pd(unsigned int);
void uv_get_pd_string(char*, unsigned int);
void uv_uart(unsigned int);

#endif // __UV_H
