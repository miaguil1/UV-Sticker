#include "uv.h"

// GUVA & GUVB Photodiodes
// Analog ADC Measurements

float uv_measure(unsigned int diode_num)
{
    uint32 pd_channel = diode_num + 3;

    float adc_counts_float = (float) adc_acquire_channel(pd_channel);
    float milli_volts = (adc_counts_float*vdd_calibration)/2048; 
    return milli_volts;
}

float uv_get_pd(unsigned int diode_num)
{
    float uv_mv = uv_measure(diode_num); //Measure Raw ADC value from Port
//    float v_out = uv_mv - amp_iov[diode_num-1] - amp_ibc[diode_num-1]*uv_gain[diode_num-1]; //Get PhotoDiode Voltage, subtract Amplifier Noise
//    float uv_current = v_out/uv_gain[diode_num-1]; //Getting PhotoDiode Current from PhotoDiode Voltage
    float uv_current = uv_mv/uv_gain[diode_num-1]; //Getting PhotoDiode Current from PhotoDiode Voltage
    float uv_pd = uv_current/uv_respons[diode_num-1]; //Getting Power Density from PhotoDiode
    return uv_pd; //Returning UV Photodiode Power Density in mW/cm^2
}

void uv_get_pd_string(char *uv_pd_string, unsigned int diode_num)
{
    float uv_pd = uv_get_pd(diode_num); //Returns the Power Density of that PhotoDiode
    sprintf(uv_pd_string, "%.4f", uv_pd); //Places the Float Value of Power Density in String
}

void uv_uart(unsigned int diode_num)
{
    char uv_pd_string[5]; //Initializes the Character Array
    uv_get_pd_string(uv_pd_string, diode_num); //Places the power density of diode in Character Vector

    char uv_uart_string[7]; //Stores UV Photodiode Power Density in Message
    uv_uart_string[0] = 'u'; //Places an s as the first element in the arrray
    uv_uart_string[6] = '\n'; //Places a new line character in the last spot in the array
    
    //Placing Value in Packet between new message carrier and last message carrier
    for(unsigned int j = 1; j<strlen(uv_pd_string); j++)
    {
        uv_uart_string[j] = uv_pd_string[j-1];    
    }
    
    //Sends the Value over UART
    for(unsigned int i = 0; i<strlen(uv_uart_string); i++)
    {
        UART_UartPutChar(uv_uart_string[i]);           
    } 
}

//Reads the state of the LED and writes that value into the GATT Database
void update_UV()
{
    CYBLE_GATTS_HANDLE_VALUE_NTF_T tempHandle; //Temporary BLE Handle
    
    //If not connected, no need to update GATT Database/Server
    if(CyBle_GetState() != CYBLE_STATE_CONNECTED)
    {
        return; //Leaves the function update_UV()
    }
    tempHandle.attrHandle = CYBLE_LIGHTS_CAPSENSE_CHAR_HANDLE;
    //Cast it into a 8 bit integer pointer
    tempHandle.value.val = (uint8 *)&fingerPos; //Storing the finger's Position
    tempHandle.value.len = 2; //Uint16 value is stored as 2 8 bit integer
    CyBle_GattsWriteAttributeValue(&tempHandle, 0, &cyBle_connHandle, 0); //Writing new value to Gatt Server    
    
    //If capsenseNotify is 1, i.e. there is a change in the Capsense, Notification is sent to Android Phone
    if(capsenseNotify && (fingerPos != fingerPosOld))
    {
        CyBle_GattsNotification(cyBle_connHandle, &tempHandle); //Sends out Notification to Gatt Central
        fingerPosOld = fingerPos;
    }
}