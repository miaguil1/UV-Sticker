#include "system.h"
#include "bluetooth.h"
#include "uv.h"
#include "battery.h"
#include "tmp116.h"
#include "led.h"

uint8 busStatus = CYBLE_STACK_STATE_FREE;           /* Status of stack queue */

volatile uint32 mainTimer = 0;

/*******************************************************************************
* Function Name: Timer_Interrupt
********************************************************************************
*
* Summary:
*  Handles the Interrupt Service Routine for the WDT timer.
*
*******************************************************************************/
CY_ISR(Timer_ISR_Handler)
{
    if(CySysWdtGetInterruptSource() & WDT_I)
    {
        /* Blink LED to indicate that device advertises */
        if(CYBLE_STATE_ADVERTISING == CyBle_GetState())
        {
//            led ^= LED_OFF;
//            Advertising_LED_Write(led);
        }
        
        /* Indicate that timer is raised to the main loop */
        mainTimer++;
        
        /* Clears interrupt request  */
        CySysWdtClearInterrupt(WDT_INTERRUPT_SOURCE);
    }
    //Insert update functions for different components & sensors
    update_tmp116();
    update_LED();
    update_battery();
    Timer_ClearInterrupt(Timer_INTR_MASK_TC);
}
CY_ISR(WDT_ISR_Handler)
{
    /* This variable is used to generate required WDT interrupt period */
uint32 ILODelayCycles = WDT_MATCH_VALUE_200MS;
    //CySysWdtClearInterrupt();
    //CySysWdtDisable();  // Disable watchdog reset
        /* Update the match register for generating a periodic WDT ISR.
    Note: In order to do a periodic ISR using WDT, Match value needs to be
    updated every WDT ISR with the desired time value added on top of the
    existing match value */
    CySysWdtWriteMatch(ILODelayCycles);

    /* Enable the WDT interrupt in SRSS INTR mask register */
    CySysWdtUnmaskInterrupt();

    /* Map the WatchDog_ISR vector to the WDT_ISR */
    isr_WDT_StartEx(WDT_ISR);
    
                /* Configure the wake up period to 30ms */
            ILODelayCycles = WDT_MATCH_VALUE_30MS;

            /* Disable WDT interrupt */
            CySysWdtMaskInterrupt();

            /* Set WDT interrupt period */
            CySysWdtWriteMatch((uint16)CySysWdtReadCount() + ILODelayCycles);

            /* Enable WDT interrupt */
            CySysWdtUnmaskInterrupt();
            
                    /* Prepare CapSense component for Deep-Sleep mode */
        CapSense_Sleep();

        /* Enter Deep-Sleep */
        CySysPmDeepSleep();

        /* Reconfigure CapSense component after Deep-Sleep */
        CapSense_Wakeup();
}

/******************************************************************************
* Function Name: WDT_ISR_Handler
*******************************************************************************
*
* Summary:
* Interrupt Service Routine for the watchdog timer interrupt. The periodicity
* of the interrupt is depended on the match value written into the counter
* register using API - CySysWdtWriteMatch().
*
******************************************************************************/
CY_ISR(WDT_ISR)
{
    /* Clear WDT interrupt */
    CySysWdtClearInterrupt();

    /* Write WDT_MATCH with current match value + desired match value */
    CySysWdtWriteMatch((uint16)CySysWdtReadMatch()+ILODelayCycles);
}
/* [] END OF FILE */

int main()
{
    system_enable_interrupts(); //Enabling Global Interrupts
    system_init_hardware(); //Starting all hardware modules: UART, I2C, SG-AMP, UV-AMP, ADC 
    
    bluetooth_start(); //Starting CYBLE, Generic Event Handler, 
    Timer_ISR_StartEx(Timer_ISR_Handler); //Starting the Timer ISR Handler Stack
    WDT_ISR_StartEx(WDT_ISR_Handler); //Starting the Watchdog Timer
	while(1) 
    {   
        bluetooth_process(); //Process BLE Stack Events

        if(CyBle_GetState() == CYBLE_STATE_CONNECTED)
        {       
            if(mainTimer != 0u)
            {
                mainTimer = 0u;
                
                MeasureBattery();
                CyBle_ProcessEvents();
                
                if(temperatureMeasure == ENABLED)
                {
                    MeasureTemperature();
                    CyBle_ProcessEvents();
                }
            }
        }
        

            
            if(pos!=0xFF)
            {
                CYBLE_GATTS_HANDLE_VALUE_NTF_T capsenseHandle;
                
                capsenseHandle.attrHandle = CYBLE_CAPSENSE_SLIDER_CHAR_HANDLE;
                capsenseHandle.value.val = &pos;
                capsenseHandle.value.len = 1;
                
                CyBle_GattsWriteAttributeValue(&capsenseHandle, 0, &connectionHandle, 0);
                
                if(uv_Power_Notify)
                {
                    CyBle_GattsNotification(BLE_Connection_Handle, &capsenseHandle);
                }
            }
        }
        

        CyBle_ProcessEvents();
        CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
	}   
}

