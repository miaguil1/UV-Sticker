#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H
#include "system.h"   

CYBLE_CONN_HANDLE_T BLE_Connection_Handle;  //Bluetooth Connection Handle for Stack
int uv_Power_Notify; //Boolean to determine UV power notification is on
int uv_Index_Notify; //Boolean to determine UV Index notification is on
int temperature_Notify; //Boolean to determine Temperature notification is on
int respiration_Notify; //Boolean to determine Respiration notification is on
int battery_Notify; //Boolean to determine Battery notification is on

void BLE_Stack_Handler(uint32 eventCode, void *eventParam);
static void bluetooth_start(void);
static void bluetooth_process(void);
    

#endif // __BLUETOOTH_H

