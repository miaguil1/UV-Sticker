#ifndef __HTS_H
#define __HTS_H
#include "system.h"

#define SIM_TEMPERATURE_MIN         (15)        /* Minimum simulated temperature measurement */
#define SIM_TEMPERATURE_MAX         (40)        /* Maximum simulated temperature measurement */
#define SIM_TEMPERATURE_INCREMENT   (1)         /* Value by which the temperature is incremented */                             

#define HTS_TEMP_DATA_MIN_SIZE      (5u)    

extern uint16 temperatureMeasure;
    
void HtsCallBack(uint32 event, void *eventParam);
void MeasureTemperature(void);

#endif // __HTS_H